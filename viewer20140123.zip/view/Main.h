#ifndef Main_h
#define Main_h 1

#include <string>
#include <cctype>
#include <iostream>
#include <vector>
#include "ViewM3d.h"
#include "ViewMdl.h"


#endif

