#include "JoinPoint.h"

JoinPoint::JoinPoint(int index, int newindex){
  nidx = newindex;
  idx = index;
}

JoinPoint::~JoinPoint(){

}

