#ifndef JoinMdl_h
#define JoinMdl_h 1

#include <string>
#include <cctype>
#include <iostream>
#include <vector>
#include "../read_write/ReadMdl.h"
#include "../read_write/WriteMdl.h"
#include "JoinPoint.h"


#endif

