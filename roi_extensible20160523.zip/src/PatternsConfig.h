// Configured options and settingd for Tutorial
#define Patterns_VERSION_MAJOR 1
#define Patterns_VERSION_MINOR 0
