#include "stdafx.h"
#include "Point3D.h"

namespace Clobscode
{
	Point3D::Point3D(){
		x=y=z=0;
	}
	
	Point3D::Point3D(double x, double y, double z){
		this->x=x;
		this->y=y;
		this->z=z;
	}
	
	Point3D::~Point3D(){
		
	}
	
	Point3D Point3D::cross(Point3D p){
		Point3D ret;
		ret[0]=y*p[2] - z*p[1];
		ret[1]=z*p[0] - x*p[2];
		ret[2]=x*p[1] - y*p[0];
		return ret;
	}
	
	//cross product operator
	Point3D Point3D::operator^(Point3D p){
		Point3D ret;
		ret[0]=y*p[2] - z*p[1];
		ret[1]=z*p[0] - x*p[2];
		ret[2]=x*p[1] - y*p[0];
		return ret;
	}
	
	double Point3D::dot(Point3D p){
		return x*p[0] + y*p[1] + z*p[2];
	}
	
	double Point3D::operator*(Point3D p){
		return x*p[0] + y*p[1] + z*p[2];
	}
	
	double Point3D::distance(Point3D p){
		return ((*this)-p).Norm();
	}
	
	double Point3D::DistanceTo(const Point3D &p){
		return ((*this)-p).Norm();
	}
	
	double Point3D::DistanceTo(const Point3D &p) const{
		return ((*this)-p).Norm();
	}
	
	void Point3D::normalize(){
		double nor=Norm();
		if(nor!=0){
			x/=nor;
			y/=nor;
			z/=nor;
		}
		else
			x=y=z=0;
	}
	
	double Point3D::Norm(){
		return sqrt(x*x + y*y + z*z);
	}
	
	string Point3D::print(){
		ostringstream o;
		string out;
		
		o << x << " ";
		o << y << " ";
		o << z;
		
		out = o.str();
		return out;
	}
	
	std::ostream& operator<<(std::ostream& o,Point3D &p){
		o << p.print().c_str();
		return o;
	}
	
	bool operator==(Point3D &p1,Point3D &p2){
		Point3D p=p1-p2;
		double dx=p[0],dy=p[1],dz=p[2];
		double epsilon=1E-6;
		if(dx<0) dx*=-1;
		if(dy<0) dy*=-1;
		if(dz<0) dz*=-1;
		if(dx>epsilon)
			return false;
		if(dy>epsilon)
			return false;
		if(dz>epsilon)
			return false;
		return true;
	}
	
	bool operator!=(Point3D &p1,Point3D &p2){
		return !(p1==p2);
	}
	
	Point3D Point3D::operator-(){
		Point3D p;
		p[0]=-x;
		p[1]=-y;
		p[2]=-z;
		return p;
	}
	
	Point3D Point3D::operator-(Point3D p2){
		Point3D p;
		p[0]=x-p2[0];
		p[1]=y-p2[1];
		p[2]=z-p2[2];
		return p;
	}
	
	Point3D Point3D::operator+(Point3D p2){
		Point3D p;
		p[0]=x+p2[0];
		p[1]=y+p2[1];
		p[2]=z+p2[2];
		return p;
	}
	
	void Point3D::operator/=(double div){
		x/=div;
		y/=div;
		z/=div;
	}
	
	/*void Point3D::operator+=(Point3D p2){
		x+=p2[0];
		y+=p2[1];
		z+=p2[2];
	}*/
	
	void Point3D::operator=(Point3D p){
		x=p[0];
		y=p[1];
		z=p[2];
	}
	
	double &Point3D::operator[](int pos){
		if(pos==0)
			return x;
		if(pos==1)
			return y;
		return z;
	}
	
	Point3D Point3D::operator*(double escalar){
		Point3D ret;
		ret[0] = x*escalar;
		ret[1] = y*escalar;
		ret[2] = z*escalar;
		return ret;
	}
}
