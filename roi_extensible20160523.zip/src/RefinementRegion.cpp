#include "stdafx.h"
#include "RefinementRegion.h"

namespace Clobscode
{
	//--------------------------------------------------------------------------------
	//--------------------------------------------------------------------------------
	RefinementRegion::RefinementRegion()
	{
		refine_level = 0;
        local_rot = false;
        input_rot = false;
	}
	//--------------------------------------------------------------------------------
	//--------------------------------------------------------------------------------
	RefinementRegion::~RefinementRegion()
	{
		
	}
	
}
