//#include "Visitor.h"

/*namespace Clobscode
{

    Visitor::Visitor()
    {

    }

}
*/